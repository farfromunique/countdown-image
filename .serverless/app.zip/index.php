<?php

var_export($_SERVER);
echo "\n<br />";
var_export($_GET);
