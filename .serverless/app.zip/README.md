countdown-image
